export interface Emerald {
  id: string;
  title: string;
  description: string;
  price: number;
  carat: number;
  origin: string;
  images: string[];
  seller: {
    id: string;
    name: string;
    rating: number;
    verified: boolean;
  };
  certification: {
    lab: string;
    certificateNumber: string;
    date: string;
    url: string;
  };
  listed: string; // date string
}

export interface User {
  id: string;
  name: string;
  email: string;
  isVerified: boolean;
  joined: string; // date string
}

export interface PolishingRequest {
  id: string;
  userId: string;
  emeraldId?: string; // Optional if user is uploading their own emerald
  customUpload?: boolean;
  polishType: 'standard' | 'premium' | 'custom';
  status: 'pending' | 'approved' | 'in-progress' | 'completed' | 'shipped';
  requestDate: string;
  scheduledDate?: string;
  completionDate?: string;
  notes?: string;
}

export interface Order {
  id: string;
  emeraldId: string;
  buyerId: string;
  sellerId: string;
  price: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'canceled';
  orderDate: string;
  paymentMethod: string;
  shippingAddress: string;
}

export type FilterOptions = {
  origin: string[];
  caratMin: number;
  caratMax: number;
  priceMin: number;
  priceMax: number;
}

export type SortOption = 'price-asc' | 'price-desc' | 'newest' | 'oldest' | 'carat-asc' | 'carat-desc';