import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, ShoppingBag, Tag, Briefcase, Settings, Clock, BarChart2 } from 'lucide-react';

const DashboardSidebar = () => {
  const navItems = [
    { name: 'Overview', path: '/dashboard', icon: <LayoutDashboard size={20} /> },
    { name: 'My Listings', path: '/dashboard/listings', icon: <Tag size={20} /> },
    { name: 'Purchase History', path: '/dashboard/purchases', icon: <ShoppingBag size={20} /> },
    { name: 'Sales History', path: '/dashboard/sales', icon: <Briefcase size={20} /> },
    { name: 'Polishing Services', path: '/dashboard/polishing', icon: <Clock size={20} /> },
    { name: 'Analytics', path: '/dashboard/analytics', icon: <BarChart2 size={20} /> },
    { name: 'Settings', path: '/dashboard/settings', icon: <Settings size={20} /> },
  ];

  return (
    <div className="bg-white shadow-md rounded-lg overflow-hidden">
      <div className="p-6 border-b border-slate-200">
        <h2 className="text-lg font-medium text-slate-900">Dashboard</h2>
      </div>
      <nav className="p-4">
        <ul className="space-y-1">
          {navItems.map((item) => (
            <li key={item.path}>
              <NavLink
                to={item.path}
                className={({ isActive }) =>
                  `flex items-center px-4 py-3 rounded-md transition-colors ${
                    isActive
                      ? 'bg-teal-50 text-teal-700'
                      : 'text-slate-700 hover:text-teal-700 hover:bg-slate-50'
                  }`
                }
                end={item.path === '/dashboard'}
              >
                <span className="mr-3">{item.icon}</span>
                <span>{item.name}</span>
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
};

export default DashboardSidebar;