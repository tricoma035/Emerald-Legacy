import React from 'react';

type CardProps = {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
};

const Card = ({ children, className = '', hover = false }: CardProps) => {
  const hoverEffect = hover 
    ? 'transition-all duration-300 hover:shadow-lg hover:-translate-y-1'
    : '';

  return (
    <div className={`bg-white rounded-lg shadow-md overflow-hidden ${hoverEffect} ${className}`}>
      {children}
    </div>
  );
};

export const CardHeader = ({ children, className = '' }: { children: React.ReactNode; className?: string }) => {
  return <div className={`p-4 border-b border-slate-200 ${className}`}>{children}</div>;
};

export const CardContent = ({ children, className = '' }: { children: React.ReactNode; className?: string }) => {
  return <div className={`p-4 ${className}`}>{children}</div>;
};

export const CardFooter = ({ children, className = '' }: { children: React.ReactNode; className?: string }) => {
  return <div className={`p-4 border-t border-slate-200 ${className}`}>{children}</div>;
};

export default Card;