import React, { useState } from 'react';

type EmeraldDetailGalleryProps = {
  images: string[];
  title: string;
};

const EmeraldDetailGallery = ({ images, title }: EmeraldDetailGalleryProps) => {
  const [selectedImage, setSelectedImage] = useState(0);

  return (
    <div className="space-y-4">
      <div className="aspect-square overflow-hidden rounded-lg relative">
        <img
          src={images[selectedImage]}
          alt={`${title} - Image ${selectedImage + 1}`}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/0 hover:bg-black/5 transition-colors cursor-zoom-in"></div>
      </div>

      <div className="grid grid-cols-4 gap-2">
        {images.map((image, index) => (
          <button
            key={index}
            onClick={() => setSelectedImage(index)}
            className={`aspect-square rounded-md overflow-hidden border-2 transition-all ${
              selectedImage === index
                ? 'border-teal-700 opacity-100'
                : 'border-transparent opacity-70 hover:opacity-100'
            }`}
          >
            <img
              src={image}
              alt={`${title} - Thumbnail ${index + 1}`}
              className="w-full h-full object-cover"
            />
          </button>
        ))}
      </div>
    </div>
  );
};

export default EmeraldDetailGallery;