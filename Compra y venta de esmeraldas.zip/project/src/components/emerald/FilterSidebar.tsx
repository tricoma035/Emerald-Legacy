import React, { useState } from 'react';
import { FilterOptions } from '../../types';
import { origins } from '../../data/mockData';
import Button from '../ui/Button';

type FilterSidebarProps = {
  filterOptions: FilterOptions;
  setFilterOptions: React.Dispatch<React.SetStateAction<FilterOptions>>;
  onApplyFilters: () => void;
};

const FilterSidebar = ({ filterOptions, setFilterOptions, onApplyFilters }: FilterSidebarProps) => {
  const [selectedOrigins, setSelectedOrigins] = useState<string[]>(filterOptions.origin || []);
  const [priceRange, setPriceRange] = useState<{ min: number; max: number }>({
    min: filterOptions.priceMin || 0,
    max: filterOptions.priceMax || 50000,
  });
  const [caratRange, setCaratRange] = useState<{ min: number; max: number }>({
    min: filterOptions.caratMin || 0,
    max: filterOptions.caratMax || 10,
  });

  const handleOriginChange = (origin: string) => {
    if (selectedOrigins.includes(origin)) {
      setSelectedOrigins(selectedOrigins.filter((o) => o !== origin));
    } else {
      setSelectedOrigins([...selectedOrigins, origin]);
    }
  };

  const handleApplyFilters = () => {
    setFilterOptions({
      origin: selectedOrigins,
      priceMin: priceRange.min,
      priceMax: priceRange.max,
      caratMin: caratRange.min,
      caratMax: caratRange.max,
    });
    onApplyFilters();
  };

  const handleResetFilters = () => {
    setSelectedOrigins([]);
    setPriceRange({ min: 0, max: 50000 });
    setCaratRange({ min: 0, max: 10 });
    setFilterOptions({
      origin: [],
      priceMin: 0,
      priceMax: 50000,
      caratMin: 0,
      caratMax: 10,
    });
    onApplyFilters();
  };

  return (
    <div className="space-y-6 p-4 bg-white rounded-lg shadow-md">
      <div>
        <h3 className="text-lg font-medium text-slate-900 mb-3">Origin</h3>
        <div className="space-y-2">
          {origins.map((origin) => (
            <div key={origin} className="flex items-center">
              <input
                id={`origin-${origin}`}
                type="checkbox"
                className="h-4 w-4 text-teal-600 focus:ring-teal-500 border-slate-300 rounded"
                checked={selectedOrigins.includes(origin)}
                onChange={() => handleOriginChange(origin)}
              />
              <label htmlFor={`origin-${origin}`} className="ml-2 text-sm text-slate-700">
                {origin}
              </label>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium text-slate-900 mb-3">Price Range</h3>
        <div className="space-y-3">
          <div className="flex justify-between text-sm text-slate-600">
            <span>${priceRange.min.toLocaleString()}</span>
            <span>${priceRange.max.toLocaleString()}</span>
          </div>
          <input
            type="range"
            min="0"
            max="50000"
            step="1000"
            value={priceRange.max}
            onChange={(e) => setPriceRange({ ...priceRange, max: Number(e.target.value) })}
            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer"
          />
          <div className="flex items-center gap-2">
            <div className="flex-grow">
              <label htmlFor="price-min" className="block text-sm text-slate-700 mb-1">Min</label>
              <input
                id="price-min"
                type="number"
                min="0"
                max={priceRange.max}
                value={priceRange.min}
                onChange={(e) => setPriceRange({ ...priceRange, min: Number(e.target.value) })}
                className="w-full p-2 text-sm border border-slate-300 rounded-md focus:ring-teal-500 focus:border-teal-500"
              />
            </div>
            <div className="flex-grow">
              <label htmlFor="price-max" className="block text-sm text-slate-700 mb-1">Max</label>
              <input
                id="price-max"
                type="number"
                min={priceRange.min}
                max="50000"
                value={priceRange.max}
                onChange={(e) => setPriceRange({ ...priceRange, max: Number(e.target.value) })}
                className="w-full p-2 text-sm border border-slate-300 rounded-md focus:ring-teal-500 focus:border-teal-500"
              />
            </div>
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium text-slate-900 mb-3">Carat Range</h3>
        <div className="space-y-3">
          <div className="flex justify-between text-sm text-slate-600">
            <span>{caratRange.min} ct</span>
            <span>{caratRange.max} ct</span>
          </div>
          <input
            type="range"
            min="0"
            max="10"
            step="0.1"
            value={caratRange.max}
            onChange={(e) => setCaratRange({ ...caratRange, max: Number(e.target.value) })}
            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer"
          />
          <div className="flex items-center gap-2">
            <div className="flex-grow">
              <label htmlFor="carat-min" className="block text-sm text-slate-700 mb-1">Min</label>
              <input
                id="carat-min"
                type="number"
                min="0"
                max={caratRange.max}
                step="0.1"
                value={caratRange.min}
                onChange={(e) => setCaratRange({ ...caratRange, min: Number(e.target.value) })}
                className="w-full p-2 text-sm border border-slate-300 rounded-md focus:ring-teal-500 focus:border-teal-500"
              />
            </div>
            <div className="flex-grow">
              <label htmlFor="carat-max" className="block text-sm text-slate-700 mb-1">Max</label>
              <input
                id="carat-max"
                type="number"
                min={caratRange.min}
                max="10"
                step="0.1"
                value={caratRange.max}
                onChange={(e) => setCaratRange({ ...caratRange, max: Number(e.target.value) })}
                className="w-full p-2 text-sm border border-slate-300 rounded-md focus:ring-teal-500 focus:border-teal-500"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-col space-y-2">
        <Button onClick={handleApplyFilters} fullWidth>Apply Filters</Button>
        <Button variant="outline" onClick={handleResetFilters} fullWidth>Reset Filters</Button>
      </div>
    </div>
  );
};

export default FilterSidebar;