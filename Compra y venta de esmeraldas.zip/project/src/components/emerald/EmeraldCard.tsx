import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Award } from 'lucide-react';
import { Emerald } from '../../types';
import Card, { CardContent } from '../ui/Card';
import Badge from '../ui/Badge';

type EmeraldCardProps = {
  emerald: Emerald;
};

const EmeraldCard = ({ emerald }: EmeraldCardProps) => {
  return (
    <Card hover className="h-full flex flex-col">
      <div className="aspect-square relative overflow-hidden group">
        <img
          src={emerald.images[0]}
          alt={emerald.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <button className="absolute top-4 right-4 bg-white/80 p-2 rounded-full hover:bg-white transition-colors">
          <Heart className="h-5 w-5 text-slate-600" />
        </button>
        {emerald.seller.verified && (
          <div className="absolute bottom-4 left-4">
            <Badge variant="success" className="flex items-center">
              <Award className="h-3 w-3 mr-1" />
              Verified Seller
            </Badge>
          </div>
        )}
      </div>
      <CardContent className="flex-grow flex flex-col justify-between">
        <div>
          <h3 className="text-lg font-semibold mb-1 text-slate-900">
            <Link to={`/buy/${emerald.id}`} className="hover:text-teal-700 transition-colors">
              {emerald.title}
            </Link>
          </h3>
          <div className="flex justify-between items-center mb-2">
            <div>
              <span className="text-sm text-slate-600">{emerald.carat} ct • {emerald.origin}</span>
            </div>
            <div className="flex items-center">
              <span className="text-amber-600 text-sm font-medium">GIA Certified</span>
            </div>
          </div>
          <p className="text-slate-600 text-sm line-clamp-3 mb-4">{emerald.description}</p>
        </div>
        <div className="flex justify-between items-end">
          <div>
            <span className="text-xl font-bold text-slate-900">${emerald.price.toLocaleString()}</span>
          </div>
          <Link 
            to={`/buy/${emerald.id}`}
            className="text-sm font-medium text-teal-700 hover:text-teal-800 transition-colors"
          >
            View Details
          </Link>
        </div>
      </CardContent>
    </Card>
  );
};

export default EmeraldCard;